//
//  PasswordToggleTextField.swift
//  Test5
//
//  Created by IOS on 13/02/24.
//

import Foundation
import UIKit

class PasswordToggleTextField: UITextField {

    private let eyeButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(UIImage(systemName: "eye"), for: .normal)
        button.setImage(UIImage(systemName: "eye.slash"), for: .selected)
        button.tintColor = .systemGray
        return button
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupEyeButton()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupEyeButton()
    }
    
    private func setupEyeButton() {
        eyeButton.addTarget(self, action: #selector(eyeButtonTapped), for: .touchUpInside)
        rightView = eyeButton
        rightViewMode = .always
        isSecureTextEntry = true
    }
    
    @objc private func eyeButtonTapped() {
        isSecureTextEntry.toggle()
        eyeButton.isSelected = !isSecureTextEntry
    }
}
