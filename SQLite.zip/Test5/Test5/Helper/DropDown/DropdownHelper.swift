//
//  DropdownHelper.swift
//  Test5
//
//  Created by IOS on 13/02/24.
//

import Foundation
import UIKit

let dropdownHelper = DropdownHelper.shared

class DropdownHelper {
    
    static let shared = DropdownHelper()
    private let dropDownGender = DropDown()
    
    private init() {
        setupDropdown()
    }
    
    private func setupDropdown() {
        dropDownGender.direction = .bottom
        dropDownGender.bottomOffset = CGPoint(x: 0, y: UIDevice.current.userInterfaceIdiom == .pad ? 80:55) // Adjust the offset as needed
        dropDownGender.textFont = UIDevice.current.userInterfaceIdiom == .pad ? UIFont.systemFont(ofSize: 19) : UIFont.systemFont(ofSize: 20, weight: .medium)
        dropDownGender.selectionBackgroundColor = .clear
        dropDownGender.textColor = .white
        dropDownGender.selectedTextColor = UIColor(hex: "84D552")
        dropDownGender.cornerRadius = 10
        dropDownGender.backgroundColor = UIColor(hex: "36454f")
    }
    
    func setupDropdown(dataSource: [String], anchorView: UIView,selectionAction: @escaping (Int, String) -> Void) {
        dropDownGender.anchorView = anchorView
        dropDownGender.dataSource = dataSource
        dropDownGender.selectionAction = selectionAction
    }
    
    func showDropdown() {
        dropDownGender.show()
    }
}
