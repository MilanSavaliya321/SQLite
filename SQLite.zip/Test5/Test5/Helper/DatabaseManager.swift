//
//  Db.swift
//  Test5
//
//  Created by IOS on 13/02/24.
//

import Foundation
import UIKit
import FMDB

class DatabaseManager {
    static let shared = DatabaseManager()
    let databaseFileName = "milan.sqlite"
    var databasePath: String!
    var database: FMDatabase!

    private init() {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        databasePath = documentsDirectory.appendingPathComponent(databaseFileName).path
        database = FMDatabase(path: databasePath)
        print(databasePath ?? "")
    }

    func openDatabase() -> Bool {
        if database.open() {
            return true
        } else {
            print("Unable to open database")
            return false
        }
    }

    func closeDatabase() {
        database.close()
    }
}

extension DatabaseManager {
    
    func createUserTable() {
        guard openDatabase() else { return }
        defer { closeDatabase() }
        
        let createUserTableQuery = """
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                fullName TEXT,
                email TEXT,
                phone TEXT,
                password TEXT,
                dob TEXT,
                gender TEXT
            )
        """
        do {
            try database.executeUpdate(createUserTableQuery, values: nil)
            print("User table created successfully")
        } catch {
            print("Error creating user table: \(error.localizedDescription)")
        }
    }

    func insertUser(user: User) {
        guard openDatabase() else { return }
        defer { closeDatabase() }
        
        let insertUserQuery = """
            INSERT INTO users (id, fullName, email, phone, password, dob, gender)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """
        do {
            try database.executeUpdate(insertUserQuery, values: [user.id, user.fullName, user.email, user.phone, user.password, user.dob, user.gender])
            print("User inserted successfully")
        } catch {
            print("Error inserting user: \(error.localizedDescription)")
        }
    }

    func getAllUsers() -> [User] {
        guard openDatabase() else { return [] }
        defer { closeDatabase() }
        
        var users = [User]()
        let getAllUsersQuery = "SELECT * FROM users"
        do {
            let resultSet = try database.executeQuery(getAllUsersQuery, values: nil)
            while resultSet.next() {
                let user = User(
                    id: resultSet.string(forColumn: "id") ?? "",
                    fullName: resultSet.string(forColumn: "fullName") ?? "",
                    email: resultSet.string(forColumn: "email") ?? "",
                    phone: resultSet.string(forColumn: "phone") ?? "",
                    password: resultSet.string(forColumn: "password") ?? "",
                    dob: resultSet.string(forColumn: "dob") ?? "",
                    gender: resultSet.string(forColumn: "gender") ?? ""
                )
                users.append(user)
            }
        } catch {
            print("Error retrieving users: \(error.localizedDescription)")
        }
        return users
    }

    func updateUser(user: User) {
        guard openDatabase() else { return }
        defer { closeDatabase() }
        
        let updateUserQuery = """
            UPDATE users
            SET fullName = ?, email = ?, phone = ?, password = ?, dob = ?, gender = ?
            WHERE id = ?
        """
        do {
            try database.executeUpdate(updateUserQuery, values: [user.fullName, user.email, user.phone, user.password, user.dob, user.gender, user.id])
            let user = getUserByEmail(email: user.email)
            loggedInUser = user
            print("User updated successfully")
        } catch {
            print("Error updating user: \(error.localizedDescription)")
        }
    }

    func deleteUser(id: String) {
        guard openDatabase() else { return }
        defer { closeDatabase() }
        
        let deleteUserQuery = "DELETE FROM users WHERE id = ?"
        do {
            try database.executeUpdate(deleteUserQuery, values: [id])
            print("User deleted successfully")
        } catch {
            print("Error deleting user: \(error.localizedDescription)")
        }
    }
}

extension DatabaseManager {
    func isUserExists(email: String) -> Bool {
        var userExists = false
        if openDatabase() {
            let checkUserQuery = "SELECT COUNT(*) FROM users WHERE email = ?"
            do {
                let result = try database.executeQuery(checkUserQuery, values: [email])
                if result.next() {
                    let count = result.int(forColumnIndex: 0)
                    userExists = count > 0
                }
            } catch {
                print("Error checking user existence: \(error.localizedDescription)")
            }
            closeDatabase()
        }
        return userExists
    }
}

extension DatabaseManager {
    func getUserByEmail(email: String) -> User? {
        var user: User?
        if openDatabase() {
            let getUserQuery = "SELECT * FROM users WHERE email = ?"
            do {
                let resultSet = try database.executeQuery(getUserQuery, values: [email])
                if resultSet.next() {
                    user = User(
                        id: resultSet.string(forColumn: "id") ?? "",
                        fullName: resultSet.string(forColumn: "fullName") ?? "",
                        email: resultSet.string(forColumn: "email") ?? "",
                        phone: resultSet.string(forColumn: "phone") ?? "",
                        password: resultSet.string(forColumn: "password") ?? "",
                        dob: resultSet.string(forColumn: "dob") ?? "",
                        gender: resultSet.string(forColumn: "gender") ?? ""
                    )
                }
            } catch {
                print("Error retrieving user: \(error.localizedDescription)")
            }
            closeDatabase()
        }
        return user
    }
}
