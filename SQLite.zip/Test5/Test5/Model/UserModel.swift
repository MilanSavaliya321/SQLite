//
//  UserModel.swift
//  Test5
//
//  Created by IOS on 13/02/24.
//

import Foundation

class User {
    var id: String
    var fullName: String
    var email: String
    var phone: String
    var password: String
    var dob: String
    var gender: String
    
    init(id: String, fullName: String, email: String, phone: String, password: String, dob: String, gender: String) {
        self.id = id
        self.fullName = fullName
        self.email = email
        self.phone = phone
        self.password = password
        self.dob = dob
        self.gender = gender
    }
}
