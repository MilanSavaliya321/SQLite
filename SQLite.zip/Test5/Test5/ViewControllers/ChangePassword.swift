//
//  ChangePassword.swift
//  Test5
//
//  Created by IOS on 13/02/24.
//

import UIKit

class ChangePassword: UIViewController {
    
    @IBOutlet weak var txtOldPassword: UITextField!
    @IBOutlet weak var txtNewPassword: UITextField!
    @IBOutlet weak var txtCPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func onBtnBack(_ sender: Any) {
        self.popVC()
    }
    
    @IBAction func onBtnSave(_ sender: Any) {
        guard let user = loggedInUser else {
            return
        }
        
        guard let oldPassword = txtOldPassword.text, !oldPassword.isEmpty else {
            showToast("Please enter your old password.")
            return
        }
        
        guard let newPassword = txtNewPassword.text, !newPassword.isEmpty else {
            showToast("Please enter a new password.")
            return
        }
        
        guard let confirmPassword = txtCPassword.text, !confirmPassword.isEmpty else {
            showToast("Please confirm your new password.")
            return
        }
        
        if user.password != oldPassword {
            showToast("Old password does not match.")
            return
        }
        
        if newPassword != confirmPassword {
            showToast("New password and confirm password do not match.")
            return
        }
        
        user.password = newPassword
        DatabaseManager.shared.updateUser(user: user)
        showToast("Password updated successfully.")
        popDVC()
    }
}
