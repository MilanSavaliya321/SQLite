//
//  LoginVC.swift
//  Test5
//
//  Created by IOS on 13/02/24.
//

import UIKit
import Toast

class LoginVC: UIViewController {
    
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var rememberMeButton: UIButton!
    
    let defaults = UserDefaults.standard
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Load saved email and password
        txtEmail.text = ""
        txtPassword.text = ""
        if let savedEmail = defaults.string(forKey: "savedEmail"),
           let savedPassword = defaults.string(forKey: "savedPassword") {
            txtEmail.text = savedEmail
            txtPassword.text = savedPassword
            rememberMeButton.isSelected = true
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func onBtnRememberMe(_ sender: UIButton) {
        sender.isSelected.toggle()
        
        if sender.isSelected {
            defaults.set(txtEmail.text, forKey: "savedEmail")
            defaults.set(txtPassword.text, forKey: "savedPassword")
        } else {
            defaults.removeObject(forKey: "savedEmail")
            defaults.removeObject(forKey: "savedPassword")
        }
    }
    
    @IBAction func obBtnSignin(_ sender: Any) {
        if rememberMeButton.isSelected {
            defaults.set(txtEmail.text, forKey: "savedEmail")
            defaults.set(txtPassword.text, forKey: "savedPassword")
        } else {
            defaults.removeObject(forKey: "savedEmail")
            defaults.removeObject(forKey: "savedPassword")
        }
        
        guard let email = txtEmail.text, !email.isEmpty,
              let password = txtPassword.text, !password.isEmpty else {
            showToast("Please enter an email and password.")
            return
        }
        
        // Retrieve user from database
        guard let user = DatabaseManager.shared.getUserByEmail(email: email) else {
            showToast("User not found. Please check your credentials.")
            return
        }
        
        // Check if the password matches
        if user.password == password {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DashboardVC") as? DashboardVC
            loggedInUser = user
            self.push(vc: vc)
        } else {
            showToast("Incorrect password. Please try again.")
        }
    }
    
    @IBAction func onBtnSignup(_ sender: Any) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignUpVC") as? SignUpVC
        self.push(vc: vc)
    }
    
}
