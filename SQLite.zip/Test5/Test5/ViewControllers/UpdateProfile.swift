//
//  UpdateProfile.swift
//  Test5
//
//  Created by IOS on 13/02/24.
//

import UIKit

class UpdateProfile: UIViewController {

    @IBOutlet weak var viewDob: FloatingDatePicker!
    @IBOutlet weak var txtFullName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var txtDob: UITextField!
    @IBOutlet weak var txtGender: UITextField!
    @IBOutlet weak var btnGender: UIButton!
    @IBOutlet weak var viewRound1: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewRound1.roundCorners(corners: [.bottomLeft, .bottomRight], radius: 30)
        populateUserData()
        viewDob.txtDate.placeholder = "Date of Birth"
        dropdownHelper.setupDropdown(dataSource: ["Male", "Female"], anchorView: btnGender) { [weak self] index, item in
            self?.txtGender.text = item
        }
    }
    
    func populateUserData() {
        guard let user = loggedInUser else {
            return
        }
        txtFullName.text = user.fullName
        txtEmail.text = user.email
        txtPhone.text = user.phone
        viewDob.txtDate.text = user.dob
        txtGender.text = user.gender
    }

    @IBAction func onBtnDrop1(_ sender: UIButton) {
        dropdownHelper.showDropdown()
    }
    
    @IBAction func onBtnBack(_ sender: Any) {
        self.popVC()
    }
    
    @IBAction func onBtnUpdate(_ sender: Any) {
        guard let user = loggedInUser else {
            return
        }
        
        user.fullName = txtFullName.text ?? ""
        user.email = txtEmail.text ?? ""
        user.phone = txtPhone.text ?? ""
        user.dob = viewDob.txtDate.text ?? ""
        user.gender = txtGender.text ?? ""
        
        DatabaseManager.shared.updateUser(user: user)
        
        showToast("User data updated successfully")
        
        popDVC()
    }
}
