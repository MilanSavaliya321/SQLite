//
//  DashboardVC.swift
//  Test5
//
//  Created by IOS on 13/02/24.
//

import UIKit

var loggedInUser: User?

class DashboardVC: UIViewController {
    
    @IBOutlet weak var viewOption: UIView!
    @IBOutlet weak var imgProfile: UIImageView!
    
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblGender: UILabel!
    @IBOutlet weak var lblDob: UILabel!
    @IBOutlet weak var lblPhone: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblRole: UILabel!
    
    @IBOutlet weak var viewRound1: UIView!
    @IBOutlet weak var viewRound2: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewRound1.roundCorners(corners: [.bottomLeft, .bottomRight], radius: 30)
        viewRound2.roundCorners(corners: [.bottomLeft, .bottomRight], radius: 30)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setData()
    }
    
    func setData() {
        guard let user = loggedInUser else {
            return
        }
        lblName.text = user.fullName
        lblEmail.text = user.email
        lblPhone.text = user.phone
        lblDob.text = user.dob
        lblGender.text = user.gender
        lblRole.text = "Sr.iOS Devloper"
    }
    
    func deleteUser() {
        guard let user = loggedInUser else {
            return
        }
        DatabaseManager.shared.deleteUser(id: user.id)
        showToast("Your account has been deleted.")
        popDVC()
    }
    
    @IBAction func onBtnOption(_ sender: UIButton) {
        UIView.transition(with: view, duration: 0.3, options: .transitionCrossDissolve, animations: {
            self.viewOption.alpha = self.viewOption.isHidden ? 1.0 : 0.0
            self.viewOption.isHidden.toggle()
        })
    }
    
    @IBAction func obBtnEdit(_ sender: Any) {
        viewOption.isHidden = true
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UpdateProfile") as? UpdateProfile
        self.push(vc: vc)
    }
    
    @IBAction func obBtnChangePassword(_ sender: Any) {
        viewOption.isHidden = true
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChangePassword") as? ChangePassword
        self.push(vc: vc)
    }
    
    @IBAction func obBtnLogout(_ sender: Any) {
        loggedInUser = nil
        self.popRootVC()
    }
    
    @IBAction func obBtnUpdate(_ sender: Any) {
        viewOption.isHidden = true
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UpdateProfile") as? UpdateProfile
        self.push(vc: vc)
    }
    
    @IBAction func obBtnDalete(_ sender: Any) {
        let alert = UIAlertController(title: "Confirm Deletion", message: "Are you sure you want to delete your account?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .destructive, handler: { _ in
            self.deleteUser()
        }))
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
}
