//
//  SignUpVC.swift
//  Test5
//
//  Created by IOS on 13/02/24.
//

import UIKit

class SignUpVC: UIViewController {
    
    @IBOutlet weak var viewDob: FloatingDatePicker!
    @IBOutlet weak var txtFullName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtCPassword: UITextField!
    @IBOutlet weak var txtDob: UITextField!
    @IBOutlet weak var txtGender: UITextField!
    @IBOutlet weak var btnGender: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTextFeield()
        dropdownHelper.setupDropdown(dataSource: ["Male", "Female"], anchorView: btnGender) { [weak self] index, item in
            self?.txtGender.text = item
        }
    }
    
    func setupTextFeield() {
        viewDob.txtDate.placeholder = "Date of Birth"
        txtPassword.disableAutoFill()
        txtCPassword.disableAutoFill()
    }
        
    @IBAction func onBtnDrop1(_ sender: UIButton) {
        dropdownHelper.showDropdown()
    }
    
    @IBAction func obBtnSignin(_ sender: Any) {
        self.popVC()
    }
    
    @IBAction func onBtnSignup(_ sender: Any) {
        if txtFullName.text?.isEmpty ?? true {
            showToast("Full name field is empty")
            return
        }
        if txtEmail.text?.isEmpty ?? true {
            showToast("Email field is empty")
            return
        }
        if txtPhone.text?.isEmpty ?? true {
            showToast("Phone field is empty")
            return
        }
        if txtPassword.text?.isEmpty ?? true {
            showToast("Password field is empty")
            return
        }
        if txtCPassword.text?.isEmpty ?? true {
            showToast("Confirm password field is empty")
            return
        }
        if viewDob.txtDate.text?.isEmpty ?? true {
            showToast("Date of birth field is empty")
            return
        }
        if txtGender.text?.isEmpty ?? true {
            showToast("Gender field is empty")
            return
        }
        
        // Check if password and confirm password match
        if txtPassword.text != txtCPassword.text {
            showToast("Password and confirm password do not match")
            return
        }
        
        guard let fullName = txtFullName.text, !fullName.isEmpty,
              let email = txtEmail.text, !email.isEmpty,
              let phone = txtPhone.text, !phone.isEmpty,
              let password = txtPassword.text, !password.isEmpty,
              let confirmPassword = txtCPassword.text, !confirmPassword.isEmpty,
              let dob = viewDob.txtDate.text, !dob.isEmpty,
              let gender = txtGender.text, !gender.isEmpty else {
            showToast("Please fill in all fields")
            return
        }
        
        // Check if user already exists
        if DatabaseManager.shared.isUserExists(email: email) {
            showToast("User with this email already exists")
            return
        }
        
        let user = User(id: UUID().uuidString, fullName: fullName, email: email, phone: phone, password: password, dob: dob, gender: gender)
        
        // Insert the user into the database
        DatabaseManager.shared.insertUser(user: user)
        
        showToast("User registered successfully")
        popDVC()
    }
    
}
extension UITextField {
    func disableAutoFill() {
        if #available(iOS 12, *) {
            textContentType = .oneTimeCode
        } else {
            textContentType = .init(rawValue: "")
        }
    }
}
